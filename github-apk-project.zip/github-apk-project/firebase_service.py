# -*- coding: utf-8 -*-
"""
خدمة Firebase - تسجيل الدخول/الحساب + قاعدة بيانات Firestore
عبر REST API مباشرة (بدون SDK رسمي، لأنه غير مدعوم جيداً في بايثون للموبايل)
"""

import time
import requests
from firebase_config import (
    FIREBASE_WEB_API_KEY,
    FIREBASE_PROJECT_ID,
    AUTH_SIGNUP_URL,
    AUTH_SIGNIN_URL,
    FIRESTORE_BASE_URL,
)


class FirebaseError(Exception):
    pass


class FirebaseService:
    """كلاس واحد يدير الجلسة الحالية (اليوزر المسجل دخول) وكل عمليات القراءة/الكتابة."""

    def __init__(self):
        self.id_token = None
        self.local_id = None  # uid
        self.email = None

    # ---------------------- Auth ----------------------

    def register(self, name, email, password):
        url = AUTH_SIGNUP_URL.format(FIREBASE_WEB_API_KEY)
        resp = requests.post(url, json={
            "email": email,
            "password": password,
            "returnSecureToken": True,
        }, timeout=15)
        data = resp.json()
        if "error" in data:
            raise FirebaseError(self._translate_error(data["error"].get("message", "")))

        self.id_token = data["idToken"]
        self.local_id = data["localId"]
        self.email = email

        # احفظ بيانات المستخدم بمجموعة users
        self.set_document("users", self.local_id, {
            "name": name,
            "email": email,
            "createdAt": int(time.time() * 1000),
        })
        return self.local_id

    def login(self, email, password):
        url = AUTH_SIGNIN_URL.format(FIREBASE_WEB_API_KEY)
        resp = requests.post(url, json={
            "email": email,
            "password": password,
            "returnSecureToken": True,
        }, timeout=15)
        data = resp.json()
        if "error" in data:
            raise FirebaseError(self._translate_error(data["error"].get("message", "")))

        self.id_token = data["idToken"]
        self.local_id = data["localId"]
        self.email = email
        return self.local_id

    def logout(self):
        self.id_token = None
        self.local_id = None
        self.email = None

    def is_logged_in(self):
        return self.id_token is not None

    @staticmethod
    def _translate_error(code):
        mapping = {
            "EMAIL_EXISTS": "هذا البريد الإلكتروني مسجل مسبقاً",
            "EMAIL_NOT_FOUND": "البريد الإلكتروني غير مسجل",
            "INVALID_PASSWORD": "كلمة المرور غير صحيحة",
            "INVALID_LOGIN_CREDENTIALS": "بيانات الدخول غير صحيحة",
            "WEAK_PASSWORD : Password should be at least 6 characters": "كلمة المرور ضعيفة (6 أحرف على الأقل)",
            "INVALID_EMAIL": "صيغة البريد الإلكتروني غير صحيحة",
        }
        for key, msg in mapping.items():
            if key in code:
                return msg
        return f"خطأ: {code}"

    # ---------------------- Firestore helpers ----------------------

    def _headers(self):
        return {"Authorization": f"Bearer {self.id_token}"}

    @staticmethod
    def _to_firestore_fields(data: dict) -> dict:
        """يحول dict بايثون عادي إلى صيغة Firestore REST (typed fields)."""
        fields = {}
        for key, value in data.items():
            if isinstance(value, bool):
                fields[key] = {"booleanValue": value}
            elif isinstance(value, int):
                fields[key] = {"integerValue": str(value)}
            elif isinstance(value, float):
                fields[key] = {"doubleValue": value}
            else:
                fields[key] = {"stringValue": str(value)}
        return fields

    @staticmethod
    def _from_firestore_fields(fields: dict) -> dict:
        """يحول صيغة Firestore REST إلى dict بايثون عادي."""
        result = {}
        for key, value in fields.items():
            if "stringValue" in value:
                result[key] = value["stringValue"]
            elif "integerValue" in value:
                result[key] = int(value["integerValue"])
            elif "doubleValue" in value:
                result[key] = float(value["doubleValue"])
            elif "booleanValue" in value:
                result[key] = value["booleanValue"]
            else:
                result[key] = None
        return result

    def set_document(self, collection, doc_id, data: dict):
        url = f"{FIRESTORE_BASE_URL.format(FIREBASE_PROJECT_ID)}/{collection}/{doc_id}"
        payload = {"fields": self._to_firestore_fields(data)}
        resp = requests.patch(url, json=payload, headers=self._headers(), timeout=15)
        if resp.status_code not in (200, 201):
            raise FirebaseError(f"فشل الحفظ: {resp.text}")
        return True

    def add_document(self, collection, data: dict):
        """يضيف مستند جديد بمعرف تلقائي، يرجع الـ id."""
        url = f"{FIRESTORE_BASE_URL.format(FIREBASE_PROJECT_ID)}/{collection}"
        payload = {"fields": self._to_firestore_fields(data)}
        resp = requests.post(url, json=payload, headers=self._headers(), timeout=15)
        if resp.status_code not in (200, 201):
            raise FirebaseError(f"فشل الإضافة: {resp.text}")
        result = resp.json()
        doc_name = result["name"]  # .../documents/devices/XXXX
        return doc_name.split("/")[-1]

    def update_field(self, collection, doc_id, field_name, value):
        url = (f"{FIRESTORE_BASE_URL.format(FIREBASE_PROJECT_ID)}/{collection}/{doc_id}"
               f"?updateMask.fieldPaths={field_name}")
        payload = {"fields": self._to_firestore_fields({field_name: value})}
        resp = requests.patch(url, json=payload, headers=self._headers(), timeout=15)
        if resp.status_code not in (200, 201):
            raise FirebaseError(f"فشل التحديث: {resp.text}")
        return True

    def delete_document(self, collection, doc_id):
        url = f"{FIRESTORE_BASE_URL.format(FIREBASE_PROJECT_ID)}/{collection}/{doc_id}"
        resp = requests.delete(url, headers=self._headers(), timeout=15)
        if resp.status_code not in (200,):
            raise FirebaseError(f"فشل الحذف: {resp.text}")
        return True

    def get_document(self, collection, doc_id):
        url = f"{FIRESTORE_BASE_URL.format(FIREBASE_PROJECT_ID)}/{collection}/{doc_id}"
        resp = requests.get(url, headers=self._headers(), timeout=15)
        if resp.status_code != 200:
            raise FirebaseError(f"تعذر الجلب: {resp.text}")
        data = resp.json()
        fields = self._from_firestore_fields(data.get("fields", {}))
        fields["id"] = doc_id
        return fields

    def list_devices(self, owner_uid):
        """يجلب كل أجهزة المستخدم الحالي (owner_uid) مرتبة من الأحدث."""
        url = f"{FIRESTORE_BASE_URL.format(FIREBASE_PROJECT_ID)}:runQuery"
        query = {
            "structuredQuery": {
                "from": [{"collectionId": "devices"}],
                "where": {
                    "fieldFilter": {
                        "field": {"fieldPath": "ownerUid"},
                        "op": "EQUAL",
                        "value": {"stringValue": owner_uid},
                    }
                },
                "orderBy": [{"field": {"fieldPath": "createdAt"}, "direction": "DESCENDING"}],
            }
        }
        full_url = f"{FIRESTORE_BASE_URL.format(FIREBASE_PROJECT_ID).rsplit('/documents', 1)[0]}/documents:runQuery"
        resp = requests.post(full_url, json=query, headers=self._headers(), timeout=15)
        if resp.status_code != 200:
            raise FirebaseError(f"تعذر جلب الأجهزة: {resp.text}")

        devices = []
        for item in resp.json():
            doc = item.get("document")
            if not doc:
                continue
            fields = self._from_firestore_fields(doc.get("fields", {}))
            fields["id"] = doc["name"].split("/")[-1]
            devices.append(fields)
        return devices


# نسخة واحدة مشتركة بكل التطبيق (Singleton بسيط)
firebase = FirebaseService()
