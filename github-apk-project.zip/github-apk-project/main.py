# -*- coding: utf-8 -*-
"""
تطبيق صيانة الشاشات - نسخة بايثون (Kivy + KivyMD)
نفس تصميم وفكرة النسخة الأندرويد الأصلية، مبني بالكامل ببايثون.
"""

from kivy.lang import Builder
from kivy.core.text import LabelBase
from kivy.uix.screenmanager import ScreenManager, SlideTransition
from kivymd.app import MDApp

from screens.login_screen import LoginScreen
from screens.register_screen import RegisterScreen
from screens.main_screen import MainScreen
from screens.add_device_screen import AddDeviceScreen
from screens.device_details_screen import DeviceDetailsScreen

# خط عربي (اختياري - حسّن اعرض النص العربي إذا توفر الخط بمجلد assets)
try:
    LabelBase.register(name="Arabic", fn_regular="assets/Cairo-Regular.ttf")
except Exception:
    pass


class MaintenanceApp(MDApp):
    def build(self):
        self.theme_cls.primary_palette = "Blue"
        self.theme_cls.theme_style = "Light"
        self.title = "صيانة الشاشات"

        Builder.load_file("screens/login_screen.kv")
        Builder.load_file("screens/register_screen.kv")
        Builder.load_file("screens/main_screen.kv")
        Builder.load_file("screens/add_device_screen.kv")
        Builder.load_file("screens/device_details_screen.kv")

        sm = ScreenManager(transition=SlideTransition())
        sm.add_widget(LoginScreen(name="login"))
        sm.add_widget(RegisterScreen(name="register"))
        sm.add_widget(MainScreen(name="main"))
        sm.add_widget(AddDeviceScreen(name="add_device"))
        sm.add_widget(DeviceDetailsScreen(name="device_details"))
        return sm


if __name__ == "__main__":
    MaintenanceApp().run()
