# -*- coding: utf-8 -*-
"""
إعدادات Firebase
================
عبّي القيم التالية من لوحة تحكم Firebase:
console.firebase.google.com -> اختر مشروعك -> Project settings -> General

- FIREBASE_WEB_API_KEY: من "Web API Key" (نفس الصفحة)
- FIREBASE_PROJECT_ID: معرف المشروع (Project ID)
"""

FIREBASE_WEB_API_KEY = "AIzaSyAS-ZX_G2sncfW5mmAxfbkjWZT5d8uDEm4"
FIREBASE_PROJECT_ID = "login-screen-e42b9"

# روابط Firebase REST API (لا تحتاج تعديل)
AUTH_SIGNUP_URL = "https://identitytoolkit.googleapis.com/v1/accounts:signUp?key={}"
AUTH_SIGNIN_URL = "https://identitytoolkit.googleapis.com/v1/accounts:signInWithPassword?key={}"
FIRESTORE_BASE_URL = "https://firestore.googleapis.com/v1/projects/{}/databases/(default)/documents"
