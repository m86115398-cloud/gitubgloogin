# -*- coding: utf-8 -*-
import threading
from kivy.uix.screenmanager import Screen
from kivy.clock import Clock
from kivymd.uix.card import MDCard
from kivymd.uix.boxlayout import MDBoxLayout

from firebase_service import firebase, FirebaseError

STATUS_COLORS = {
    "قيد الصيانة": (0.97, 0.66, 0.15, 1),
    "تم الإصلاح": (0.18, 0.49, 0.2, 1),
    "تم التسليم": (0.08, 0.4, 0.75, 1),
}


class DeviceCard(MDCard):
    """بطاقة تعرض بيانات جهاز واحد في القائمة."""

    def __init__(self, device, on_press_callback, **kwargs):
        super().__init__(**kwargs)
        self.device = device
        self.device_model = device.get("deviceModel", "")
        self.customer_name = device.get("customerName", "")
        self.issue = device.get("issueDescription", "")
        self.cost = str(device.get("cost", 0))
        self.status = device.get("status", "قيد الصيانة")
        self.status_color = STATUS_COLORS.get(self.status, (0.5, 0.5, 0.5, 1))
        self.on_press_callback = on_press_callback

    def on_touch_up(self, touch):
        if self.collide_point(*touch.pos) and self.on_press_callback:
            self.on_press_callback(self.device)
        return super().on_touch_up(touch)


class MainScreen(Screen):

    def __init__(self, **kwargs):
        super().__init__(**kwargs)
        self.all_devices = []

    def on_pre_enter(self, *args):
        self.load_devices()

    def load_devices(self):
        if not firebase.is_logged_in():
            self.manager.current = "login"
            return
        threading.Thread(target=self._fetch_devices, daemon=True).start()

    def _fetch_devices(self):
        try:
            devices = firebase.list_devices(firebase.local_id)
            Clock.schedule_once(lambda dt: self._on_devices_loaded(devices))
        except FirebaseError as e:
            Clock.schedule_once(lambda dt: self._on_error(str(e)))

    def _on_devices_loaded(self, devices):
        self.all_devices = devices
        self._render_list(devices)

    def _on_error(self, message):
        self.ids.empty_label.text = f"خطأ: {message}"
        self.ids.empty_label.opacity = 1
        self.ids.empty_label.height = "60dp"

    def _render_list(self, devices):
        container = self.ids.device_list
        container.clear_widgets()

        if not devices:
            self.ids.empty_label.text = "لا توجد أجهزة حالياً، اضغط + لإضافة جهاز جديد"
            self.ids.empty_label.opacity = 1
            self.ids.empty_label.height = "60dp"
            return

        self.ids.empty_label.opacity = 0
        self.ids.empty_label.height = "0dp"

        for device in devices:
            card = DeviceCard(device=device, on_press_callback=self.open_device_details)
            container.add_widget(card)

    def filter_devices(self, query):
        query = (query or "").strip().lower()
        if not query:
            self._render_list(self.all_devices)
            return
        filtered = [
            d for d in self.all_devices
            if query in d.get("customerName", "").lower() or query in d.get("deviceModel", "").lower()
        ]
        self._render_list(filtered)

    def open_device_details(self, device):
        details_screen = self.manager.get_screen("device_details")
        details_screen.set_device(device)
        self.manager.current = "device_details"

    def go_to_add_device(self):
        self.manager.current = "add_device"

    def logout(self):
        firebase.logout()
        self.manager.current = "login"
