# -*- coding: utf-8 -*-
import threading
import time
from kivy.uix.screenmanager import Screen
from kivy.clock import Clock
from kivymd.toast import toast

from firebase_service import firebase, FirebaseError


class AddDeviceScreen(Screen):

    def on_pre_enter(self, *args):
        for field_id in ("customer_name_field", "customer_phone_field",
                          "device_model_field", "issue_field", "cost_field"):
            self.ids[field_id].text = ""
        self.ids.status_spinner.text = "قيد الصيانة"

    def save_device(self):
        name = self.ids.customer_name_field.text.strip()
        phone = self.ids.customer_phone_field.text.strip()
        model = self.ids.device_model_field.text.strip()
        issue = self.ids.issue_field.text.strip()
        cost_text = self.ids.cost_field.text.strip()
        status = self.ids.status_spinner.text

        if not name or not model or not issue:
            toast("الرجاء تعبئة الحقول المطلوبة")
            return

        if not firebase.is_logged_in():
            toast("جلسة الدخول منتهية، سجل الدخول مجدداً")
            self.manager.current = "login"
            return

        try:
            cost = float(cost_text) if cost_text else 0.0
        except ValueError:
            cost = 0.0

        device = {
            "customerName": name,
            "customerPhone": phone,
            "deviceModel": model,
            "issueDescription": issue,
            "cost": cost,
            "status": status,
            "createdAt": int(time.time() * 1000),
            "ownerUid": firebase.local_id,
        }

        self.ids.loading_spinner.active = True
        threading.Thread(target=self._do_save, args=(device,), daemon=True).start()

    def _do_save(self, device):
        try:
            firebase.add_document("devices", device)
            Clock.schedule_once(lambda dt: self._on_success())
        except FirebaseError as e:
            Clock.schedule_once(lambda dt: self._on_error(str(e)))

    def _on_success(self):
        self.ids.loading_spinner.active = False
        toast("تم حفظ الجهاز بنجاح")
        self.manager.current = "main"

    def _on_error(self, message):
        self.ids.loading_spinner.active = False
        toast(f"فشل الحفظ: {message}")

    def go_back(self):
        self.manager.current = "main"
