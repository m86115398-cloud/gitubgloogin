# -*- coding: utf-8 -*-
import threading
from kivy.uix.screenmanager import Screen
from kivy.clock import Clock
from kivymd.uix.dialog import MDDialog
from kivymd.uix.button import MDFlatButton
from kivymd.toast import toast

from firebase_service import firebase, FirebaseError


class DeviceDetailsScreen(Screen):

    def __init__(self, **kwargs):
        super().__init__(**kwargs)
        self.device = None
        self.dialog = None

    def set_device(self, device):
        self.device = device

    def on_pre_enter(self, *args):
        if not self.device:
            return
        self.ids.model_label.text = self.device.get("deviceModel", "")
        self.ids.customer_label.text = self.device.get("customerName", "")
        self.ids.phone_label.text = self.device.get("customerPhone") or "غير محدد"
        self.ids.issue_label.text = self.device.get("issueDescription", "")
        self.ids.cost_label.text = f"{self.device.get('cost', 0)} ريال"
        self.ids.status_spinner.text = self.device.get("status", "قيد الصيانة")

    def update_status(self):
        if not self.device:
            return
        new_status = self.ids.status_spinner.text
        threading.Thread(target=self._do_update, args=(new_status,), daemon=True).start()

    def _do_update(self, new_status):
        try:
            firebase.update_field("devices", self.device["id"], "status", new_status)
            Clock.schedule_once(lambda dt: toast("تم تحديث الحالة"))
        except FirebaseError as e:
            Clock.schedule_once(lambda dt: toast(f"فشل التحديث: {e}"))

    def confirm_delete(self):
        if not self.dialog:
            self.dialog = MDDialog(
                title="تأكيد الحذف",
                text="هل أنت متأكد من حذف هذا الجهاز نهائياً؟",
                buttons=[
                    MDFlatButton(text="إلغاء", on_release=lambda x: self.dialog.dismiss()),
                    MDFlatButton(text="حذف", theme_text_color="Error",
                                 on_release=lambda x: self._delete_device()),
                ],
            )
        self.dialog.open()

    def _delete_device(self):
        self.dialog.dismiss()
        threading.Thread(target=self._do_delete, daemon=True).start()

    def _do_delete(self):
        try:
            firebase.delete_document("devices", self.device["id"])
            Clock.schedule_once(lambda dt: self._on_deleted())
        except FirebaseError as e:
            Clock.schedule_once(lambda dt: toast(f"فشل الحذف: {e}"))

    def _on_deleted(self):
        toast("تم حذف الجهاز")
        self.manager.current = "main"

    def go_back(self):
        self.manager.current = "main"
