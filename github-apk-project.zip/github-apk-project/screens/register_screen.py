# -*- coding: utf-8 -*-
from kivy.uix.screenmanager import Screen
from kivy.clock import Clock
import threading

from firebase_service import firebase, FirebaseError


class RegisterScreen(Screen):

    def on_pre_enter(self, *args):
        self.ids.error_label.text = ""

    def attempt_register(self):
        name = self.ids.name_field.text.strip()
        email = self.ids.email_field.text.strip()
        password = self.ids.password_field.text.strip()
        self.ids.error_label.text = ""

        if not name or not email or not password:
            self.ids.error_label.text = "الرجاء تعبئة جميع الحقول"
            return
        if len(password) < 6:
            self.ids.error_label.text = "كلمة المرور يجب أن تكون 6 أحرف على الأقل"
            return

        self._set_loading(True)
        threading.Thread(target=self._do_register, args=(name, email, password), daemon=True).start()

    def _do_register(self, name, email, password):
        try:
            firebase.register(name, email, password)
            Clock.schedule_once(lambda dt: self._on_success())
        except FirebaseError as e:
            Clock.schedule_once(lambda dt: self._on_error(str(e)))
        except Exception as e:
            Clock.schedule_once(lambda dt: self._on_error(f"تعذر الاتصال بالخادم: {e}"))

    def _on_success(self):
        self._set_loading(False)
        self.manager.current = "main"

    def _on_error(self, message):
        self._set_loading(False)
        self.ids.error_label.text = message

    def _set_loading(self, loading):
        self.ids.loading_spinner.active = loading

    def go_to_login(self):
        self.manager.current = "login"
