# تطبيق صيانة الشاشات - نسخة بايثون (Kivy + KivyMD)

نفس تصميم وفكرة النسخة الأندرويد الأصلية، لكن مبني بالكامل بلغة بايثون باستخدام:
- **Kivy / KivyMD** لواجهة الموبايل
- **Firebase REST API** (بدون SDK) للمصادقة وقاعدة البيانات

## الشاشات
1. `login_screen` — تسجيل الدخول
2. `register_screen` — إنشاء حساب
3. `main_screen` — قائمة أجهزة الصيانة (بحث فوري)
4. `add_device_screen` — إضافة جهاز جديد
5. `device_details_screen` — تفاصيل، تحديث حالة، حذف

---

## 1) خطوات ربط Firebase (قبل أي تشغيل)

1. أنشئ مشروع بـ [console.firebase.google.com](https://console.firebase.google.com)
2. من **Project settings → General** انسخ:
   - **Web API Key**
   - **Project ID**
3. افتح ملف `firebase_config.py` وضع القيمتين مكان:
   ```python
   FIREBASE_WEB_API_KEY = "ضع_مفتاح_API_هنا"
   FIREBASE_PROJECT_ID = "ضع_معرف_المشروع_هنا"
   ```
4. فعّل من لوحة Firebase:
   - **Authentication → Sign-in method → Email/Password**
   - **Firestore Database** (أنشئ قاعدة بيانات، وضع الاختبار مبدئياً)
5. بتبويب Rules بـ Firestore ضع:
   ```
   rules_version = '2';
   service cloud.firestore {
     match /databases/{database}/documents {
       match /devices/{deviceId} {
         allow read, update, delete: if request.auth != null && resource.data.ownerUid == request.auth.uid;
         allow create: if request.auth != null;
       }
       match /users/{userId} {
         allow read, write: if request.auth != null && request.auth.uid == userId;
       }
     }
   }
   ```

---

## 2) تجربة التطبيق على الكمبيوتر أولاً (أسرع طريقة للتأكد إنه شغّال)

```bash
pip install -r requirements.txt
python main.py
```
بيفتح نافذة تحاكي شكل التطبيق على الموبايل — جرب تسجل حساب وتضيف جهاز.

---

## 3) تحويله لملف APK (تثبيت على جوال أندرويد)

⚠️ **مهم:** أداة `buildozer` التي تبني ملف APK **تعمل فقط على Linux** (أو WSL على ويندوز، أو macOS). ما تشتغل على ويندوز مباشرة.

### الطريقة أ) باستخدام WSL (ويندوز)
1. ثبّت WSL: افتح CMD كمسؤول ونفّذ `wsl --install` ثم أعد التشغيل.
2. افتح توزيعة Ubuntu من قائمة ابدأ.
3. انسخ مجلد المشروع داخل WSL، ثم:
   ```bash
   sudo apt update && sudo apt install -y python3-pip build-essential git python3 python3-dev \
       ffmpeg libsdl2-dev libsdl2-image-dev libsdl2-mixer-dev libsdl2-ttf-dev \
       libportmidi-dev libswscale-dev libavformat-dev libavcodec-dev zlib1g-dev unzip openjdk-17-jdk
   pip install buildozer cython
   cd المسار_لمجلد_المشروع
   buildozer -v android debug
   ```
4. أول بناء ياخذ وقت طويل (يحمّل Android SDK/NDK تلقائياً). بعد ما يخلص، تلاقي ملف APK داخل مجلد `bin/`.
5. انقل ملف الـ APK لجوالك (عبر كيبل USB أو رفعه جوجل درايف) وثبّته (لازم تفعّل "تثبيت من مصادر غير معروفة" بإعدادات الجوال).

### الطريقة ب) جوجل كولاب (بدون تثبيت أي شيء على جهازك)
ممكن تشغّل buildozer داخل Google Colab (بيئة لينكس سحابية مجانية) — ترفع المشروع كملف zip، تثبت buildozer، وتبني APK، ثم تنزل الملف الناتج. لو تبي أجهز لك كراس (notebook) جاهز لهذي الطريقة، قلي وأسويها.

### الطريقة ج) خدمة GitHub Actions
ترفع المشروع لمستودع GitHub وتستخدم إجراء جاهز (action) يبني APK تلقائياً بكل مرة تعدل فيها الكود. أعقد شوي بس لا يحتاج جهاز لينكس عندك إطلاقاً.

---

## ملاحظات مهمة
- الأمان: التطبيق يحفظ `idToken` بالذاكرة فقط أثناء الجلسة (ما يحفظه بشكل دائم) — يعني لازم تسجل دخول كل مرة تفتح التطبيق. إذا تبي "تذكرني" ممكن أضيفها لاحقاً.
- الخط العربي: حطيت مكان جاهز لخط عربي (`assets/Cairo-Regular.ttf`) — نزّل أي خط عربي TTF مجاني وحطه بهذا المسار عشان يطلع النص أوضح (وإلا بيشتغل بالخط الافتراضي بدون مشاكل).
