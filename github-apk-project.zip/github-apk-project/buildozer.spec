[app]
title = صيانة الشاشات
package.name = screenrepair
package.domain = com.maintenance

source.dir = .
source.include_exts = py,png,jpg,kv,atlas,ttf

version = 1.0

requirements = python3,kivy==2.3.0,kivymd==1.2.0,requests,certifi,chardet,idna,urllib3

orientation = portrait
fullscreen = 0

icon.filename = %(source.dir)s/assets/icon.png

android.permissions = INTERNET

android.api = 34
android.minapi = 24
android.ndk = 25b
android.archs = arm64-v8a, armeabi-v7a

p4a.branch = v2024.01.21

[buildozer]
log_level = 2
warn_on_root = 1
